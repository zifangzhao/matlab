function separatePausedNSx(varargin)

% separatePausedNsx    Obsoleted. Use splitNSxPauses instead.

disp('This function is obsoleted.')
disp('Use splitNSxPauses instead.');

splitNSxPauses;